<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Contact extends Model
{
    use HasFactory;

    protected $table = 'contacts';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'full_name',
        'company',
        'role',
        'phone',
        'whatsapp',
        'email',
        'sector',
        'org_type',
        'notes',
        'source',
        'is_complete',
        'created_by',
    ];

    protected $casts = [
        'is_complete' => 'boolean',
    ];

    public function leads(): HasMany
    {
        return $table = $this->hasMany(Lead::class, 'contact_id');
    }

    public function feedback(): HasMany
    {
        return $this->hasMany(VisitorFeedback::class, 'contact_id');
    }
}
