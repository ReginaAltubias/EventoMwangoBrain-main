<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BrainUser extends Model
{
    use HasFactory;

    protected $table = 'brain_users';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'name',
        'email',
        'password',
        'role',
        'initials',
        'status',
    ];

    protected $hidden = [
        'password',
    ];
}
