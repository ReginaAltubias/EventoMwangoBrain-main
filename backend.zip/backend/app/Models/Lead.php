<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Lead extends Model
{
    use HasFactory;

    protected $table = 'leads';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'contact_id',
        'solutions',
        'main_solution',
        'need',
        'has_concrete_need',
        'timeframe',
        'interest',
        'status',
        'owner_id',
        'next_action',
        'follow_up_date',
        'notes',
        'estimated_value',
    ];

    protected $casts = [
        'solutions' => 'array',
        'follow_up_date' => 'datetime',
        'estimated_value' => 'integer',
    ];

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Contact::class, 'contact_id');
    }

    public function interactions(): HasMany
    {
        return $this->hasMany(Interaction::class, 'lead_id');
    }

    public function followUps(): HasMany
    {
        return $this->hasMany(FollowUp::class, 'lead_id');
    }

    public function meetings(): HasMany
    {
        return $this->hasMany(Meeting::class, 'lead_id');
    }
}
